import { Directive } from '@angular/core';

@Directive({
    selector: 'webview',
    standalone: true
})
export class WebviewDirective {
  constructor() { }
}
